# Greenlight — Family Guide

**The app:** https://sunnybesilly-ctrl.github.io/greenlight/

Open the link in Safari on your iPhone. To install it like an app: tap the **Share** button (the square with the arrow), scroll down, tap **Add to Home Screen**, tap **Add**.

Greenlight is a road-trip awareness map built for our family. It shows things regular map apps don't: towns with documented histories of excluding Black people after dark, counties where police stop and search Black and brown drivers at higher rates, states with weaker LGBTQ protections, and small towns that fund themselves with traffic tickets. It is a **planning and awareness tool** — it does not replace Google Maps or Waze for turn-by-turn directions, because Apple doesn't let web apps track location in the background. Use Greenlight to plan and check; use your normal maps app to navigate.

---

## The buttons (right side, top to bottom)

**Route (the winding-line icon).** Tap it, enter where you're starting and where you're going (or tap ◎ to use your current location as the start). The app draws the route and shows a card with: distance, drive time, whether you'll arrive **before or after sunset** (green = before, amber = after dark), every flagged town within about 2 miles of your route in driving order, and any documented ticket-trap towns near the route. Tap any town in the list to see it on the map. Tap × to clear.

**Flag icon — LGBTQ climate layer.** Shades whole states purple.

**Shield icon — traffic-stop disparity layer.** Shades counties red/orange.

**Stacked-squares icon — town pins.** Toggles the sundown town dots and ticket-trap dots.

**Target icon — your location.** Tap once to show yourself as a pulsing green dot (Safari will ask permission — allow it). The map follows you as you move while the screen is on. Tap again to turn it off. Drag the map to stop following without turning it off.

**The sunset chip (top right).** Counts down to local sundown wherever you are. It turns amber when you're inside 90 minutes of sunset — that's your cue to think about gas, food, and where you'll be when it gets dark.

---

## The map colors, and what they actually mean

### Town dots — sundown towns (historical)

These come from the Historical Database of Sundown Towns built by historian James Loewen and maintained at Tougaloo College, a historically Black college in Mississippi. A "sundown town" was a place that kept Black people (and sometimes other groups) out after dark — by ordinance, by signs, by violence, or by reputation. The researchers grade their confidence for each town:

- **Red — "Surely."** Strong documented evidence this was a sundown town. 341 on our map.
- **Orange — "Probable."** Good evidence, not airtight. 717.
- **Yellow — "Possible."** Some evidence or testimony. 1,133.
- **Gray — "Don't know."** Researched but unresolved. 112.
- **Blue — "Unlikely / always biracial."** Researched and likely never a sundown town. 34.
- **Green — Black town or township.** Historically Black communities — the opposite of a sundown town. 5.

Tap any dot for the town's status and a link to its full history entry on the Tougaloo site.

**What this is NOT:** a verdict on the town today. Some of these places have changed a lot; some haven't. The history matters because exclusion that lasted generations leaves a footprint — in who lives there, and sometimes in how strangers are treated. Treat red and orange dots as "be aware," not "in danger."

**What's missing:** about 5% of the database's towns (129 of 2,471) couldn't be placed on the map — they're tiny unincorporated spots. They're listed in a file called `unmapped.json` in the project. And the database itself is incomplete by its makers' own account. **No dot does not mean a town is safe.**

### Yellow/khaki dots — ticket-trap towns

Twenty-one towns and counties with documented, named evidence of funding themselves through traffic tickets — places like Estelline, TX (the famous US-287 trap), Lawtey, FL (one of only two towns AAA ever put up warning billboards about), and Warwick, GA (fines were three-quarters of the town's revenue). Bright yellow = documented trap; faded khaki = reformed or historic (like Ferguson, MO, which cut fine revenue 85% after the 2015 reforms, or Waldo, FL, which disbanded its police department).

Tap a dot for the specifics and the source. This list is **curated and small on purpose** — a national study (Governing magazine, 2019) found roughly 600 jurisdictions getting more than 10% of their budget from fines, but only the documented standouts are pinned. The general rule the pins teach: **slow to the posted limit through every small town on a highway, especially in Arkansas, Georgia, Louisiana, Oklahoma, and Texas** — the states where ticket-funded towns cluster.

### Red/orange shaded counties — traffic-stop disparities

This is from the Stanford Open Policing Project — researchers who analyzed about 100 million traffic stops nationwide. The shading covers 809 counties in 17 states (including all 254 in Texas) using Stanford's published, peer-reviewed numbers from **state patrol** stops:

- **Red — high disparity.** Multiple strong signals. 233 counties.
- **Orange — elevated.** Some signals. 433.
- **Faint gray — lower.** Few or none. 143.
- **No shading — no data.** The other 33 states. **No shading ≠ no problem.**

Tap a county for its actual numbers, like: "Black drivers: stopped at 2.1× the white rate; searched at 1.8×; searches find contraband 7 points less often." That last number is the most telling one — if police search Black drivers more but find contraband less, they're searching on weaker evidence. Researchers call it the outcome test.

**Limits, honestly:** the data is from state patrol stops, mostly 2011–2018. A calm-looking county can still contain one aggressive small-town police department (that's partly what the ticket-trap pins are for). These numbers describe patterns, not any individual officer or any stop you might experience.

### Purple shaded states — LGBTQ climate

State-by-state scores from Equaldex, which combines two things: what the **laws** are (marriage, discrimination protections, healthcare, ID documents, and more) and what **polled public attitudes** look like. Darker purple = more caution:

- **Deep purple** — index below 62. Arkansas (54) is the lowest, then Mississippi and Alabama (55).
- **Medium** — 62–69.  Texas sits at 61, just inside the deep band's edge.
- **Faint** — 70–79.
- **No shading** — 80+. The friendliest tier (Massachusetts and D.C. lead at 86).

Tap a state for its numbers and links to deeper detail, including HRC's city-by-city scores — that matters because **cities and states differ a lot**. Salt Lake City scored a perfect 100 on the city index inside a caution-tier state. Austin is not rural East Texas. State shading is the broadest brush in the app; use the city links when picking an overnight stop.

---

## How to actually use it on a trip

1. **Night before:** plan the route in the app. Look at the sunset math — if the card says you arrive after dark, look at where the last 100 miles run and decide if you'd rather leave earlier.
2. **Check the flagged towns list** on the route card. A red "Surely" town directly on your route isn't a reason to panic or add 5 hours — it's a reason to gas up before, not in, that stretch, and keep the stop count low through it.
3. **Gas and food stops:** favor the bigger interstate exits and unshaded/faint areas when you have the choice, especially within that amber 90-minute sunset window.
4. **Ticket traps:** when the route card lists one, set cruise control at the limit a mile before town and keep it there until well past.
5. **While driving:** the passenger can keep Greenlight open with the location dot on; the driver's phone runs the regular navigation app.

## What this app can't do

- No background GPS or voice navigation (Apple limits web apps) — it works while the screen is on.
- Data is historical and statistical. It cannot tell you any specific place is safe or dangerous, and an unmarked map is **not** an all-clear.
- It doesn't know about today's police activity, road closures, or anything live. Waze still does that better.

## Where the data comes from (credits)

- **Sundown towns:** Historical Database of Sundown Towns, James Loewen / Tougaloo College (justice.tougaloo.edu). Non-commercial use.
- **Traffic-stop disparities:** Stanford Open Policing Project (openpolicing.stanford.edu), published county-level results.
- **LGBTQ climate:** Equaldex Equality Index (equaldex.com), retrieved June 2026. City scores via Human Rights Campaign's Municipal Equality Index.
- **Ticket-trap towns:** Governing magazine's 2019 "Addicted to Fines" investigation, AAA, and state enforcement records.
- **Map:** OpenFreeMap / OpenStreetMap. **Routing:** GraphHopper.

This app is free, private to whoever has the link, and not a commercial product — several of these data sources are licensed for exactly that and no more.

Drive safe. Gas up early. Love y'all.
